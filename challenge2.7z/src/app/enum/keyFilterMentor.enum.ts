const keyFilterMentor = Object.freeze({
    name: 'name',
    userType: 'userType',
    entity: 'entity',
    status: 'status',
});

export default keyFilterMentor;