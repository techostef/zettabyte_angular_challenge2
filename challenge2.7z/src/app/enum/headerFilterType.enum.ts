const headerFilterType = Object.freeze({
    AUTOCOMPLATE: 'autocomplate',
    EMPTY: 'empty',
    SELECT: 'select',
    STATUS: 'status',
    TEXT: 'text',
})

export default headerFilterType;